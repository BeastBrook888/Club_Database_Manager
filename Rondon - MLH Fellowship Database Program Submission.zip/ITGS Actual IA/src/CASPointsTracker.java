package bin;

//and the number of times present for "Attendance" and "CASPointsTracker" JFrame

import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

//import javax.sound.sampled.Clip;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.SwingConstants;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.ImageIcon;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JTextPane;
import javax.swing.JTextArea;

public class CASPointsTracker extends JFrame {

	private JPanel contentPane;
	public static DefaultTableModel dtm = new DefaultTableModel();
	public static DefaultTableModel dtm2 = new DefaultTableModel();
	final Object[] row = new Object[6];
	final Object[] row2 = new Object[5];
	public static JTable caspointstracker;
	public static JTable memberslist;
	public static JScrollPane scrollPane_2;
	public static JScrollPane scrollPane_3;

	public String firstcolumn;
	public String secondcolumn;
	public String thirdcolumn;
	public String fourthcolumn;
	public String fifthcolumn;
	public String sixthcolumn;

	public static String username;
	public static String membersaccess;
	public static String attendanceaccess;
	public static String tripaccess;
	public static String accountsaccess;
	public static String casaccess;

	public JTextField search;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CASPointsTracker frame = new CASPointsTracker(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	private void filter(String query) {
		TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(dtm);
		caspointstracker.setRowSorter(tr);
		tr.setRowFilter(RowFilter.regexFilter(query));
	}
	
	public CASPointsTracker(String username2, String membersaccess2, String attendanceaccess2, String tripaccess2, String accountsaccess2, String casaccess2) {

		// Parameter passing for background variable
        username = username2;
        membersaccess = membersaccess2;
        attendanceaccess = attendanceaccess2;
        tripaccess = tripaccess2;
        accountsaccess = accountsaccess2;
        casaccess = casaccess2;
        
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 25, 1054, 685);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		Object[] columns = {"First Name", "Last Name", "# of Times Present", "Sem 1 Credits", "Sem 2 Credits", "Comments"};
		dtm.setColumnIdentifiers(columns);

		// READ FROM FILE TO UPLOAD EXISTING DATA INTO THE TABLE
		try {
			File f1 = new File("CASPointsTrackers.txt");
			  
			//Create the file
			if (f1.createNewFile())
			{
			    System.out.println("File is created!");
			} else {
			    System.out.println("File already exists.");
			}			
			
			FileReader in = new FileReader(f1); // prepares to read file
			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

			while (true) {

				firstcolumn = r.readLine();
				secondcolumn = r.readLine();
				thirdcolumn = r.readLine();
				fourthcolumn = r.readLine();
				fifthcolumn = r.readLine();
				sixthcolumn = r.readLine();
				
				if (firstcolumn == null || secondcolumn == null || thirdcolumn == null || fourthcolumn == null || fifthcolumn == null || sixthcolumn == null) {
					break;
				}

			if(caspointstracker == null) {
		        row[0] = firstcolumn;
				row[1] = secondcolumn;
				row[2] = thirdcolumn;
				row[3] = fourthcolumn;
				row[4] = fifthcolumn;
				row[5] = sixthcolumn;

				dtm.addRow(row);
			}

		}

			r.close();
		}

		catch (Exception e2) {
			System.out.println("Reading doesn't work!");
		}

		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(175, 82, 698, 188);
		contentPane.add(scrollPane_2);

		caspointstracker = new JTable();
		scrollPane_2.setViewportView(caspointstracker);
		caspointstracker.setModel(dtm);
		
//Attendance table to constantly update "number of times present" per entry
		
//		JTable attendance = new JTable();
//		attendance.setModel(dtm);
//		attendance.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//		
//		LinkedList<String> columnz = new LinkedList<String>();
//		columnz.add("First Name");
//		columnz.add("Last Name");
//		columnz.add("Number of Times Present");
//		columnz.add("Date");
//		
//		columns = columnz.toArray();
//		
//		dtm.setColumnIdentifiers(columns);
//
//		READ FROM FILE TO UPLOAD EXISTING DATA INTO THE TABLE
//		try {
//			File f1 = new File("attendance.txt"); // identifies text file
//			FileReader in = new FileReader(f1); // prepares to read file
//			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file
//
//			while (true) {
//
//				firstcolumn = r.readLine();
//				secondcolumn = r.readLine();
//				thirdcolumn = r.readLine();
//				fourthcolumn = r.readLine();
//				
//				if (firstcolumn == null || secondcolumn == null || thirdcolumn == null || fourthcolumn == null) {
//					break;
//				}
//
//			if(attendance == null) {	
//				row[0] = firstcolumn;
//				row[1] = secondcolumn;
//				row[2] = thirdcolumn;
//				row[3] = fourthcolumn;
//
//				dtm.addRow(row);
//			}
//
//		}
//
//			r.close();
//		}
//
//		catch (Exception e2) {
//			System.out.println("Reading doesn't work!");
//		}
//		
//		scrollPane_2 = new JScrollPane(attendance, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
//		scrollPane_2.setBounds(168, 82, 705, 419);
//		contentPane.add(scrollPane_2);
		
//		for (int i = 0; i < caspointstracker.getRowCount(); i++) {// For each row
//			for (int j = 0; j < caspointstracker.getColumnCount(); j++) {// For each column corresponding to the row
//				if(attendance.getValueAt(i, 0).equals(caspointstracker.getValueAt(i,0)) && attendance.getValueAt(i, 1).equals(caspointstracker.getValueAt(i,0))) {
//				
//				}
//			}
//		}	
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBackground(Color.WHITE);
		comboBox_1.setMaximumRowCount(31);
		comboBox_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		comboBox_1.setBounds(379, 390, 114, 32);
		contentPane.add(comboBox_1);
		comboBox_1.addItem(new ITGSIAComboItem("0", "1"));
		comboBox_1.addItem(new ITGSIAComboItem("1", "2"));
		comboBox_1.addItem(new ITGSIAComboItem("2", "3"));
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBackground(Color.WHITE);
		comboBox_2.setMaximumRowCount(31);
		comboBox_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		comboBox_2.setBounds(379, 433, 114, 32);
		contentPane.add(comboBox_2);
		comboBox_2.addItem(new ITGSIAComboItem("0", "1"));
		comboBox_2.addItem(new ITGSIAComboItem("1", "2"));
		comboBox_2.addItem(new ITGSIAComboItem("2", "3"));

		JLabel lblOfVls = new JLabel("# of Credits for Semester 1");
		lblOfVls.setHorizontalAlignment(SwingConstants.CENTER);
		lblOfVls.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblOfVls.setBounds(162, 384, 217, 45);
		contentPane.add(lblOfVls);

		JLabel lblName = new JLabel("First & Last Name");
		lblName.setHorizontalAlignment(SwingConstants.CENTER);
		lblName.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblName.setBounds(145, 281, 179, 45);
		contentPane.add(lblName);
		
		JSpinner spinner_3 = new JSpinner();
		spinner_3.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
		spinner_3.setFont(new Font("Tahoma", Font.BOLD, 30));
		spinner_3.setBounds(378, 339, 133, 34);
		contentPane.add(spinner_3);
		
		Object[] columns2 = {"First Name", "Last Name", "Grade Level", "Position", "Number of Times Present"};
		dtm2.setColumnIdentifiers(columns2);

		// READ FROM FILE TO UPLOAD EXISTING DATA INTO THE TABLE
		try {
			File f1 = new File("MembersList.txt"); // identifies text file
			FileReader in = new FileReader(f1); // prepares to read file
			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

			while (true) {

				firstcolumn = r.readLine();
				secondcolumn = r.readLine();
				thirdcolumn = r.readLine();
				fourthcolumn = r.readLine();
				fifthcolumn = r.readLine();
				
				if (firstcolumn == null || secondcolumn == null || thirdcolumn == null || fourthcolumn == null || fifthcolumn == null) {
					break;
				}

			if(memberslist == null) {	
				row2[0] = firstcolumn;
				row2[1] = secondcolumn;
				row2[2] = thirdcolumn;
				row2[3] = fourthcolumn;
				row2[4] = fifthcolumn;

				dtm2.addRow(row2);
			}

		}

			r.close();
		}

		catch (Exception e2) {
			System.out.println("Reading doesn't work!");
		}

		scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(175, 82, 698, 188);
		contentPane.add(scrollPane_3);

		memberslist = new JTable();
		scrollPane_3.setViewportView(memberslist);
		memberslist.setModel(dtm2);
		
		JTextArea txtrTypeHere = new JTextArea();
		txtrTypeHere.setWrapStyleWord(true);
		txtrTypeHere.setLineWrap(true);
		txtrTypeHere.setText("Type Here");
		txtrTypeHere.setBounds(175, 494, 419, 93);
		contentPane.add(txtrTypeHere);

		JComboBox name = new JComboBox();
		name.setMaximumRowCount(31);
		name.setFont(new Font("Tahoma", Font.BOLD, 20));
		name.setBackground(Color.WHITE);
		name.setBounds(324, 292, 210, 32);
		contentPane.add(name);
		
		for (int i = 0; i < memberslist.getRowCount(); i++) {
			Object firstnamee = memberslist.getValueAt(i, 0);
		    Object lastnamee = memberslist.getValueAt(i, 1);
		    
		    String firstnameee = firstnamee.toString();
		    String lastnameee = lastnamee.toString();
			
			name.addItem(firstnameee + " " + lastnameee);
		}
		
		JButton Add2 = new JButton("Add (+)");
		Add2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Object namez = name.getSelectedItem();
				String namezz = namez.toString();
				
				String[] arrSplit = namezz.split(" ");
			    
				String firstname = arrSplit[0].toString();
				//Currently doesn't work with surnames with more than 1 word
				String lastname = arrSplit[1].toString();
				
				Object sem1cred = comboBox_1.getSelectedItem();
				Object sem2cred = comboBox_2.getSelectedItem();
				Object six = spinner_3.getValue();

				String eight = six.toString();
				String sem1credd = sem1cred.toString();
				String sem2credd = sem2cred.toString();
					
				int add = JOptionPane.showConfirmDialog(null, "Would you like to add this entry to your table?");
					
				if(add == JOptionPane.YES_OPTION) {
					row[0] = firstname;
					row[1] = lastname;
					row[2] = eight;
					row[3] = sem1credd;
					row[4] = sem2credd;

					dtm.addRow(row);
				   }
				}	
		});
		Add2.setFont(new Font("Tahoma", Font.BOLD, 11));
		Add2.setBounds(175, 592, 133, 45);
		contentPane.add(Add2);

		JButton Delete2 = new JButton("Delete (-)");
		Delete2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int delete = JOptionPane.showConfirmDialog(null,
						"Would you like to delete your selected row/s from the table?");

				if (delete == JOptionPane.YES_OPTION) {
					int selRow = memberslist.getSelectedRow();
					dtm.removeRow(selRow);
				}
			}
		});
		Delete2.setFont(new Font("Tahoma", Font.BOLD, 11));
		Delete2.setBounds(348, 592, 133, 45);
		contentPane.add(Delete2);

		JButton Save2 = new JButton("Save");
		Save2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int save = JOptionPane.showConfirmDialog(null, "Are you sure you would like to save your data table?");
				
				if(save == JOptionPane.YES_OPTION) {
				
					int numOfRows = dtm.getRowCount();

					try {
						File f = new File("CASPointsTrackers.txt"); // creates text file
						FileOutputStream in = new FileOutputStream(f); // prepares text file for printing
						PrintWriter w = new PrintWriter(in); // allows for text file to be printed

						for (int x = 0; x < numOfRows; x++) {
							for (int y = 0; y < 6; y++) {
								w.println((String) dtm.getValueAt(x, y));
							}
						}

						w.close();
						JOptionPane.showMessageDialog(null, "Your employee data has been saved.");
					}

					catch (Exception e2) {
                         System.out.println("Saving doesn't work!");
					}	
				}
			}
		});
		Save2.setFont(new Font("Tahoma", Font.BOLD, 11));
		Save2.setBounds(514, 592, 126, 45);
		contentPane.add(Save2);

		JLabel lblOfOts = new JLabel("Number of Times Present");
		lblOfOts.setHorizontalAlignment(SwingConstants.CENTER);
		lblOfOts.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblOfOts.setBounds(158, 332, 211, 45);
		contentPane.add(lblOfOts);

		search = new JTextField();
		search.setHorizontalAlignment(SwingConstants.CENTER);
		search.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				String query = search.getText();
				filter(query);
			}
		});
		search.setFont(new Font("Tahoma", Font.BOLD, 14));
		search.setColumns(10);
		search.setBounds(421, 41, 452, 30);
		contentPane.add(search);
		
		JLabel lblEmployeeData = new JLabel("CAS Credit Tracker");
		lblEmployeeData.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmployeeData.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblEmployeeData.setBounds(150, -9, 733, 45);
		contentPane.add(lblEmployeeData);
		
		JLabel label_9 = new JLabel("");
		label_9.setIcon(new ImageIcon(CASPointsTracker.class.getResource("vertical line.png")));
		label_9.setBounds(138, -34, 19, 710);
		contentPane.add(label_9);
		
		JLabel label_10 = new JLabel("");
		label_10.setIcon(new ImageIcon(CASPointsTracker.class.getResource("horizontal line.png")));
		label_10.setBounds(-2, 165, 140, 14);
		contentPane.add(label_10);
		
		JButton EmployeeDataButton = new JButton("Members List");
		EmployeeDataButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(membersaccess.equalsIgnoreCase("Yes")) {
					MembersList frame = new MembersList(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
					dispose();
				}
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		EmployeeDataButton.setForeground(Color.BLACK);
		EmployeeDataButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		EmployeeDataButton.setBackground(Color.WHITE);
		EmployeeDataButton.setBounds(-2, 188, 140, 41);
		contentPane.add(EmployeeDataButton);
		
		JLabel label_11 = new JLabel("Current Account:");
		label_11.setHorizontalAlignment(SwingConstants.CENTER);
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_11.setBounds(0, 0, 140, 45);
		contentPane.add(label_11);
		
		JLabel label_12 = new JLabel("");
		label_12.setIcon(new ImageIcon(CASPointsTracker.class.getResource("/bin/horizontal line.png")));
		label_12.setBounds(-2, 227, 140, 14);
		contentPane.add(label_12);
		
		JButton OTDataButton = new JButton("Trip Data");
		OTDataButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tripaccess.equalsIgnoreCase("Yes")) {
					TripData frame = new TripData(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
					dispose();
				}
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		OTDataButton.setBackground(Color.WHITE);
		OTDataButton.setBounds(-2, 319, 140, 41);
		contentPane.add(OTDataButton);
		
		JLabel label_13 = new JLabel("");
		label_13.setIcon(new ImageIcon(CASPointsTracker.class.getResource("/bin/horizontal line.png")));
		label_13.setBounds(-2, 299, 140, 14);
		contentPane.add(label_13);
		
		JButton btnAttendance = new JButton("Attendance");
		btnAttendance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(attendanceaccess.equalsIgnoreCase("Yes")) {
					Attendance frame = new Attendance(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
					dispose();
				}
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		btnAttendance.setBackground(Color.WHITE);
		btnAttendance.setBounds(-2, 252, 140, 41);
		contentPane.add(btnAttendance);
		
		JButton button_8 = new JButton("Log Out");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 int logout = JOptionPane.showConfirmDialog(null, "Would you like to log out of your account?");
					
					if(logout == JOptionPane.YES_OPTION) {
						LogInPage frame = new LogInPage(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
						frame.setVisible(true);
						dispose();
					}
			}
		});
		button_8.setBackground(Color.WHITE);
		button_8.setBounds(0, 528, 140, 41);
		contentPane.add(button_8);
		
		JLabel label_15 = new JLabel("");
		label_15.setIcon(new ImageIcon(CASPointsTracker.class.getResource("/bin/horizontal line.png")));
		label_15.setBounds(0, 440, 140, 14);
		contentPane.add(label_15);
		
		JButton button_9 = new JButton("Close Program");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                int exit = JOptionPane.showConfirmDialog(null, "Would you like to close the program?");
				
				if(exit == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
		button_9.setBackground(Color.WHITE);
		button_9.setBounds(0, 596, 140, 41);
		contentPane.add(button_9);
		
		JLabel label_16 = new JLabel("");
		label_16.setIcon(new ImageIcon(CASPointsTracker.class.getResource("/bin/horizontal line.png")));
		label_16.setBounds(-2, 371, 140, 14);
		contentPane.add(label_16);
		
		JLabel label_17 = new JLabel("________");
		label_17.setHorizontalAlignment(SwingConstants.CENTER);
		label_17.setFont(new Font("Tahoma", Font.BOLD, 12));
		label_17.setBounds(0, 48, 140, 45);
		contentPane.add(label_17);
		label_17.setText(username);
		
		JButton btnGuide = new JButton("Instructions");
		btnGuide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "1. Fill out all the text fields below the table, especially the blank text fields.");
                JOptionPane.showMessageDialog(null, "2. To delete a row, select (click on) any row, and click the 'Delete' button.");
                JOptionPane.showMessageDialog(null, "3. To edit the data in a cell, double click it, type your revision, and click outside the table to save the edit.");
                JOptionPane.showMessageDialog(null, "4. Make sure to save your table before closing the program, otherwise your edits will not be saved.");
                JOptionPane.showMessageDialog(null, "5. If you want to copy a row to your report table, make sure you click the 'Disable Sort' button \n (sorting is automatically disabled when you open this program) and click on the column header with the arrow until it disappears. \n Then, select a row and click the 'Copy Row' button, then in the 'Create A Report' screen, then click 'Paste Row from Clipboard.' Save that table too!");
                JOptionPane.showMessageDialog(null, "6. You can search for a word/s in the table by typing in the text field above the table and beside the 'Search' button. \n Click that button, and the table will show results matching what you typed in the text field \n (make sure to match the casing of the word you are looking for). \n To show all your table entries again, delete all text from the text field and click the 'Search' button.");
                JOptionPane.showMessageDialog(null, "7. To sort any of the rows, click on the column name to sort it by ascending order, and click on it again to sort it by descending order");
                JOptionPane.showMessageDialog(null, "8. If you cannot read all the letters in a cell, \n you can hover your mouse over the gridline of the column containing the data you want to read until it becomes a horizontal two-way arrow, \n then drag it to make the column wider or thinner.");
                JOptionPane.showMessageDialog(null, "9. If you want to go to another table, click one of the buttons on the left-hand side, or if you want to change accounts, click the 'Log out' button and log into your desired account.");
                JOptionPane.showMessageDialog(null, "10. If you have any questions regarding how this program works, you can email me at 'colinrondon@brent.edu.ph' ");
			}
		});
		btnGuide.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnGuide.setBounds(740, 592, 133, 45);
		contentPane.add(btnGuide);
		
		JButton btnRemoveSort = new JButton("Enable Sort");
		btnRemoveSort.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(caspointstracker.getModel());
				caspointstracker.setRowSorter(sorter);
				
				List<RowSorter.SortKey> sortKeys = new ArrayList<>(25);
				sorter.setSortKeys(sortKeys);
				
			}
		});
		btnRemoveSort.setBounds(740, 295, 133, 23);
		contentPane.add(btnRemoveSort);
		
		JButton button = new JButton("Disable Sort");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				caspointstracker.setRowSorter(null);
				
			}
		});
		button.setBounds(740, 324, 133, 23);
		contentPane.add(button);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(ChangeAccountDetails.class.getResource("/bin/horizontal line.png")));
		label.setBounds(0, 506, 140, 14);
		contentPane.add(label);
		
		JButton btnAccountDetails = new JButton("Account Details");
		btnAccountDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(accountsaccess.equalsIgnoreCase("Yes")) {
					ChangeAccountDetails frame = new ChangeAccountDetails(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
					dispose();
				}
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
				
			}
		});
		btnAccountDetails.setBackground(Color.WHITE);
		btnAccountDetails.setBounds(0, 461, 140, 41);
		contentPane.add(btnAccountDetails);
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(CASPointsTracker.class.getResource("/bin/horizontal line.png")));
		label_2.setBounds(0, 573, 140, 14);
		contentPane.add(label_2);
		
		JButton btnCasCreditTracker = new JButton("CAS Credit Tracker");
		btnCasCreditTracker.setForeground(Color.RED);
		btnCasCreditTracker.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		btnCasCreditTracker.setBackground(Color.WHITE);
		btnCasCreditTracker.setBounds(-3, 393, 140, 41);
		contentPane.add(btnCasCreditTracker);
		
		JLabel lblTypeYourSearch = new JLabel("Type your search term in here ->");
		lblTypeYourSearch.setHorizontalAlignment(SwingConstants.CENTER);
		lblTypeYourSearch.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTypeYourSearch.setBounds(148, 30, 276, 45);
		contentPane.add(lblTypeYourSearch);
		
		JLabel lblOfCredits = new JLabel("# of Credits for Semester 2");
		lblOfCredits.setHorizontalAlignment(SwingConstants.CENTER);
		lblOfCredits.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblOfCredits.setBounds(162, 426, 217, 45);
		contentPane.add(lblOfCredits);
		
		JLabel lblComments = new JLabel("Comments");
		lblComments.setHorizontalAlignment(SwingConstants.LEFT);
		lblComments.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblComments.setBounds(168, 457, 211, 45);
		contentPane.add(lblComments);
		
		JButton button_1 = new JButton("Create New File");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int filecreation = JOptionPane.showConfirmDialog(null, "Are you sure you would like to make the current table a new .txt file?");
				
				if(filecreation == JOptionPane.YES_OPTION) {
					String filename = JOptionPane.showInputDialog("Type a name for the .txt file");
					int numOfRows = dtm.getRowCount();
					try {
						File f1 = new File(filename + ".txt"); // identifies text file
						if (f1.createNewFile())
						{
							FileOutputStream in = new FileOutputStream(f1); // prepares text file for printing
							PrintWriter w = new PrintWriter(in); // allows for text file to be printed

							for (int x = 0; x < numOfRows; x++) {
								for (int y = 0; y < 4; y++) {
									w.println((String) dtm.getValueAt(x, y));
								}
							}

							w.close();
							JOptionPane.showMessageDialog(null, "Your data has been saved.");
							System.out.println("File is created!");
						} else {
						    System.out.println("File already exists.");
						}
					}
					
					catch (Exception e2) {
						System.out.println("File could not be created or process did not work");
					}
				}
			}
		});
		button_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		button_1.setBounds(658, 440, 179, 45);
		contentPane.add(button_1);

		
		JButton btnReadAnotherFile = new JButton("Read Another File");
		btnReadAnotherFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  JFileChooser fc = new JFileChooser();
				  FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
		          fc.setFileFilter(filter);
	              int returnVal = fc.showOpenDialog(null);
	              File selectedFile = null;
	              if(returnVal == JFileChooser.APPROVE_OPTION)
	              {
	                  selectedFile = fc.getSelectedFile();
	                  String filename = selectedFile.getAbsolutePath();
	                  String actualfilename = filename.substring(filename.lastIndexOf("\\")+1);
	                  
	                  if(selectedFile.getName().toLowerCase().endsWith(".txt")) {
	                	 dtm.setRowCount(0);
	                	  try {
	              			File f1 = new File(actualfilename); // identifies text file
	              			System.out.println(actualfilename);
	              			FileReader in = new FileReader(f1); // prepares to read file
	              			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

	              			while (true) {
	              				firstcolumn = r.readLine();
	              				secondcolumn = r.readLine();
	              				thirdcolumn = r.readLine();
	              				fourthcolumn = r.readLine();
	              				
	              				if (firstcolumn == null || secondcolumn == null || thirdcolumn == null || fourthcolumn == null) {
	              					break;
	              				}

	              				row[0] = firstcolumn;
	              				row[1] = secondcolumn;
	              				row[2] = thirdcolumn;
	              				row[3] = fourthcolumn;

	              				dtm.addRow(row);
	              			
	              		}

	              			r.close();
	              		}

	              		catch (Exception e2) {
	              			System.out.println("Reading doesn't work!");
	              		}

	                  }
            			scrollPane_2.setViewportView(caspointstracker);
            			caspointstracker.setModel(dtm);
            			contentPane.add(scrollPane_2);
	              } 
			}
		});
		btnReadAnotherFile.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnReadAnotherFile.setBounds(639, 506, 204, 54);
		contentPane.add(btnReadAnotherFile);
			}
	}