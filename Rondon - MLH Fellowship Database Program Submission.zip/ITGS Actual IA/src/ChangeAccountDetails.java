package bin;

//ADD CASPointsTracker access variable
//ArrayList to automatically add event dates from Trip Data to Attendance

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

//import javax.sound.sampled.Clip;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.SwingConstants;
//import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
//import javax.swing.JTextPane;
import java.awt.datatransfer.StringSelection;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import javax.swing.JRadioButton;

public class ChangeAccountDetails extends JFrame {

	private JPanel contentPane;
	public static DefaultTableModel dtm = new DefaultTableModel();
	final Object[] row = new Object[7];
	public static JTable accountdetails;

	public String firstcolumn;
	public String secondcolumn;
	public String thirdcolumn;
	public String fourthcolumn;
	public String fifthcolumn;
	public String sixthcolumn;
	public String seventhcolumn;

	public static String username;
	public static String password;
	public static String membersaccess;
	public static String attendanceaccess;
	public static String tripaccess;
	public static String accountsaccess;
	public static String casaccess;

	public JTextField usernameentryfield;
	public JTextField passwordentryfield;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChangeAccountDetails frame = new ChangeAccountDetails(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public ChangeAccountDetails(String username2, String membersaccess2, String attendanceaccess2, String tripaccess2, String accountsaccess2, String casaccess2) {

		// Parameter passing for background variable
        username = username2;
        membersaccess = membersaccess2;
        attendanceaccess = attendanceaccess2;
        tripaccess = tripaccess2;
        accountsaccess = accountsaccess2;
        casaccess = casaccess2;
        
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 25, 897, 720);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		Object[] columns = {"Username", "Password", "Access ML", "Access A", "Access TD", "Access CCT", "Access AD"};
		dtm.setColumnIdentifiers(columns);

		// READ FROM FILE TO UPLOAD EXISTING DATA INTO THE TABLE
		try {
			File f1 = new File("UsernameAndPassword.txt"); // identifies text file
			if (f1.createNewFile())
			{
			    System.out.println("File is created!");
			} else {
			    System.out.println("File already exists.");
			}
			FileReader in = new FileReader(f1); // prepares to read file
			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

			while (true) {

				firstcolumn = r.readLine();
				secondcolumn = r.readLine();
				thirdcolumn = r.readLine();
				fourthcolumn = r.readLine();
				fifthcolumn = r.readLine();
				sixthcolumn = r.readLine();
				seventhcolumn = r.readLine();
				
				if (firstcolumn == null || secondcolumn == null || thirdcolumn == null ||
						fourthcolumn == null || fifthcolumn == null || sixthcolumn == null ||
						seventhcolumn == null) {
					break;
				}
	
			if(accountdetails == null) {	
				row[0] = firstcolumn;
				row[1] = secondcolumn;
				row[2] = thirdcolumn;
				row[3] = fourthcolumn;
				row[4] = fifthcolumn;
				row[5] = sixthcolumn;
				row[6] = seventhcolumn;

				dtm.addRow(row);
			  }
			}

			r.close();
		}

		catch (Exception e2) {
			System.out.println("Reading doesn't work!");
		}
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(175, 82, 698, 188);
		contentPane.add(scrollPane_2);

		accountdetails = new JTable();
		scrollPane_2.setViewportView(accountdetails);
		accountdetails.setModel(dtm);
		
		JLabel lblName = new JLabel("Username");
		lblName.setHorizontalAlignment(SwingConstants.CENTER);
		lblName.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblName.setBounds(119, 281, 179, 45);
		contentPane.add(lblName);

		usernameentryfield = new JTextField();
		usernameentryfield.setFont(new Font("Tahoma", Font.PLAIN, 22));
		usernameentryfield.setColumns(10);
		usernameentryfield.setBounds(295, 289, 558, 35);
		contentPane.add(usernameentryfield);
		
		passwordentryfield = new JTextField();
		passwordentryfield.setFont(new Font("Tahoma", Font.PLAIN, 22));
		passwordentryfield.setColumns(10);
		passwordentryfield.setBounds(295, 337, 558, 35);
		contentPane.add(passwordentryfield);
		
		String yes = "Yes";
	    String no = "No";
	    
	    JLabel lblAccessmembersList = new JLabel("Can Access \"Members List\"");
		lblAccessmembersList.setHorizontalAlignment(SwingConstants.CENTER);
		lblAccessmembersList.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblAccessmembersList.setBounds(150, 392, 239, 45);
		contentPane.add(lblAccessmembersList);
		
		JRadioButton rdbtnYes = new JRadioButton("Yes");
		rdbtnYes.setSelected(true);
		rdbtnYes.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdbtnYes.setBounds(406, 405, 61, 23);
		rdbtnYes.setActionCommand(yes);
		contentPane.add(rdbtnYes);
		
		JRadioButton rdbtnNo = new JRadioButton("No");
		rdbtnNo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdbtnNo.setBounds(477, 404, 111, 23);
		rdbtnNo.setActionCommand(no);
		contentPane.add(rdbtnNo);
		
		JLabel lblCanAccessattendance = new JLabel("Can Access \"Attendance\"");
		lblCanAccessattendance.setHorizontalAlignment(SwingConstants.CENTER);
		lblCanAccessattendance.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCanAccessattendance.setBounds(148, 430, 239, 45);
		contentPane.add(lblCanAccessattendance);
		
		JRadioButton radioButton = new JRadioButton("Yes");
		radioButton.setSelected(true);
		radioButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		radioButton.setBounds(406, 443, 61, 23);
		radioButton.setActionCommand(yes);
		contentPane.add(radioButton);
		
		JRadioButton radioButton_1 = new JRadioButton("No");
		radioButton_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		radioButton_1.setBounds(477, 442, 111, 23);
		radioButton_1.setActionCommand(no);
		contentPane.add(radioButton_1);
		
		JLabel lblCanAccesstrip = new JLabel("Can Access \"Trip Data\"");
		lblCanAccesstrip.setHorizontalAlignment(SwingConstants.CENTER);
		lblCanAccesstrip.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCanAccesstrip.setBounds(150, 461, 239, 45);
		contentPane.add(lblCanAccesstrip);
		
		JRadioButton radioButton_2 = new JRadioButton("Yes");
		radioButton_2.setSelected(true);
		radioButton_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		radioButton_2.setBounds(408, 474, 61, 23);
		radioButton_2.setActionCommand(yes);
		contentPane.add(radioButton_2);
		
		JRadioButton radioButton_3 = new JRadioButton("No");
		radioButton_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		radioButton_3.setBounds(479, 473, 111, 23);
		radioButton_3.setActionCommand(no);
		contentPane.add(radioButton_3);
		
		JLabel lblCanAccesscas = new JLabel("Can Access \"CAS Credit Tracker\"");
		lblCanAccesscas.setHorizontalAlignment(SwingConstants.CENTER);
		lblCanAccesscas.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCanAccesscas.setBounds(150, 497, 265, 45);
		contentPane.add(lblCanAccesscas);
		
		JRadioButton radioButton_4 = new JRadioButton("Yes");
		radioButton_4.setSelected(true);
		radioButton_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		radioButton_4.setBounds(408, 510, 61, 23);
		radioButton_4.setActionCommand(yes);
		contentPane.add(radioButton_4);
		
		JRadioButton radioButton_5 = new JRadioButton("No");
		radioButton_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		radioButton_5.setBounds(479, 509, 111, 23);
		radioButton_5.setActionCommand(no);
		contentPane.add(radioButton_5);
		
		JLabel lblCanAccessaccount = new JLabel("Can Access \"Account Details\"");
		lblCanAccessaccount.setHorizontalAlignment(SwingConstants.CENTER);
		lblCanAccessaccount.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCanAccessaccount.setBounds(150, 538, 239, 45);
		contentPane.add(lblCanAccessaccount);
		
		JRadioButton radioButton_6 = new JRadioButton("Yes");
		radioButton_6.setSelected(true);
		radioButton_6.setFont(new Font("Tahoma", Font.PLAIN, 18));
		radioButton_6.setBounds(408, 551, 61, 23);
		radioButton_6.setActionCommand(yes);
		contentPane.add(radioButton_6);
		
		JRadioButton radioButton_7 = new JRadioButton("No");
		radioButton_7.setFont(new Font("Tahoma", Font.PLAIN, 18));
		radioButton_7.setBounds(479, 550, 111, 23);
		radioButton_7.setActionCommand(no);
		contentPane.add(radioButton_7);
		
		ButtonGroup memberslistaccess = new ButtonGroup();
		memberslistaccess.add(rdbtnYes);
		memberslistaccess.add(rdbtnNo);
	    
	    ButtonGroup attendanceaccesss = new ButtonGroup();
	    attendanceaccesss.add(radioButton);
	    attendanceaccesss.add(radioButton_1);

	    ButtonGroup tripdataaccess = new ButtonGroup();
	    tripdataaccess.add(radioButton_2);
	    tripdataaccess.add(radioButton_3);
	    
	    ButtonGroup cascredittrackeraccess = new ButtonGroup();
	    cascredittrackeraccess.add(radioButton_4);
	    cascredittrackeraccess.add(radioButton_5);
	    
	    ButtonGroup accountdetailsaccess = new ButtonGroup();
	    accountdetailsaccess.add(radioButton_6);
	    accountdetailsaccess.add(radioButton_7);

		JButton Add2 = new JButton("Add (+)");
		Add2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int addyesno = JOptionPane.showConfirmDialog(null, "Are you sure you would like to add this element?");
				
				if(addyesno == JOptionPane.YES_OPTION) {
				
				String onee = usernameentryfield.getText();
				String one = passwordentryfield.getText();
				
				Object radiobuttonone = memberslistaccess.getSelection().getActionCommand(); 
				Object radiobuttontwo = attendanceaccesss.getSelection().getActionCommand();
				Object radiobuttonthree = tripdataaccess.getSelection().getActionCommand();
				Object radiobuttonfour = cascredittrackeraccess.getSelection().getActionCommand(); 
				Object radiobuttonfive = accountdetailsaccess.getSelection().getActionCommand();
				
				String three = radiobuttonone.toString();
				String four = radiobuttontwo.toString();
				String five = radiobuttonthree.toString();
				String six = radiobuttonfour.toString();
				String seven = radiobuttonfive.toString();
				
				row[0] = onee;
				row[1] = one;
				row[2] = three;
				row[3] = four;
				row[4] = five;
				row[5] = six;
				row[6] = seven;
			
					dtm.addRow(row);
					usernameentryfield.setText(null);
					passwordentryfield.setText(null);

				   }
			}
		});

		Add2.setFont(new Font("Tahoma", Font.BOLD, 11));
		Add2.setBounds(167, 639, 133, 45);
		contentPane.add(Add2);

		JButton Delete2 = new JButton("Delete (-)");
		Delete2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int delete = JOptionPane.showConfirmDialog(null,
						"Would you like to delete your selected row/s from the table?");

				if (delete == JOptionPane.YES_OPTION) {
					int selRow = accountdetails.getSelectedRow();
					dtm.removeRow(selRow);
				}
			}
		});
		Delete2.setFont(new Font("Tahoma", Font.BOLD, 11));
		Delete2.setBounds(340, 639, 133, 45);
		contentPane.add(Delete2);

		JButton Save2 = new JButton("Save");
		Save2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int save = JOptionPane.showConfirmDialog(null, "Are you sure you would like to save these account details?");
				
				if(save == JOptionPane.YES_OPTION) {
				
					int numOfRows = dtm.getRowCount();

					try {
						File f = new File("UsernameAndPassword.txt"); // creates text file
						FileOutputStream in = new FileOutputStream(f); // prepares text file for printing
						PrintWriter w = new PrintWriter(in); // allows for text file to be printed

						for (int x = 0; x < numOfRows; x++) {
							for (int y = 0; y < 7; y++) {
								w.println((String) dtm.getValueAt(x, y));
							}
						}

						w.close();
						JOptionPane.showMessageDialog(null, "Your data has been saved.");
					}

					catch (Exception e2) {
                         System.out.println("Saving doesn't work!");
					}	
				}
			}
		});
		Save2.setFont(new Font("Tahoma", Font.BOLD, 11));
		Save2.setBounds(506, 639, 126, 45);
		contentPane.add(Save2);
		
		JLabel lblEmployeeData = new JLabel("Change Account Details");
		lblEmployeeData.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmployeeData.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblEmployeeData.setBounds(150, -9, 733, 45);
		contentPane.add(lblEmployeeData);
		
		JLabel label_9 = new JLabel("");
		label_9.setIcon(new ImageIcon(ChangeAccountDetails.class.getResource("/bin/vertical line.png")));
		label_9.setBounds(138, -34, 19, 799);
		contentPane.add(label_9);
		
		JLabel label_11 = new JLabel("Current Account:");
		label_11.setHorizontalAlignment(SwingConstants.CENTER);
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_11.setBounds(0, 0, 140, 45);
		contentPane.add(label_11);
		
		JLabel label_12 = new JLabel("");
		label_12.setIcon(new ImageIcon(ChangeAccountDetails.class.getResource("/bin/horizontal line.png")));
		label_12.setBounds(0, 198, 140, 14);
		contentPane.add(label_12);
		
		JLabel label_13 = new JLabel("");
		label_13.setIcon(new ImageIcon(ChangeAccountDetails.class.getResource("/bin/horizontal line.png")));
		label_13.setBounds(0, 270, 140, 14);
		contentPane.add(label_13);
		
		JLabel label_14 = new JLabel("");
		label_14.setIcon(new ImageIcon(ChangeAccountDetails.class.getResource("/bin/horizontal line.png")));
		label_14.setBounds(0, 417, 140, 14);
		contentPane.add(label_14);
		
		JButton button_8 = new JButton("Log Out");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 int logout = JOptionPane.showConfirmDialog(null, "Would you like to log out of your account?");
					
					if(logout == JOptionPane.YES_OPTION) {
						LogInPage frame = new LogInPage(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
						frame.setVisible(true);
						dispose();
					}
			}
		});
		button_8.setBackground(Color.WHITE);
		button_8.setBounds(0, 565, 140, 41);
		contentPane.add(button_8);
		
		JLabel label_15 = new JLabel("");
		label_15.setIcon(new ImageIcon(ChangeAccountDetails.class.getResource("/bin/horizontal line.png")));
		label_15.setBounds(0, 482, 140, 14);
		contentPane.add(label_15);
		
		JButton button_9 = new JButton("Close Program");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                int exit = JOptionPane.showConfirmDialog(null, "Would you like to close the program?");
				
				if(exit == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
		button_9.setBackground(Color.WHITE);
		button_9.setBounds(0, 638, 140, 41);
		contentPane.add(button_9);
		
		JLabel label_16 = new JLabel("");
		label_16.setIcon(new ImageIcon(ChangeAccountDetails.class.getResource("/bin/horizontal line.png")));
		label_16.setBounds(0, 342, 140, 14);
		contentPane.add(label_16);
		
		JLabel label_17 = new JLabel("________");
		label_17.setHorizontalAlignment(SwingConstants.CENTER);
		label_17.setFont(new Font("Tahoma", Font.BOLD, 12));
		label_17.setBounds(0, 48, 140, 45);
		contentPane.add(label_17);
		label_17.setText(username);
		
		JButton btnGuide = new JButton("Instructions");
		btnGuide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "1. Fill out all the text fields below the table, especially the blank text fields.");
                JOptionPane.showMessageDialog(null, "2. To delete a row, select (click on) any row, and click the 'Delete' button.");
                JOptionPane.showMessageDialog(null, "3. To edit the data in a cell, double click it, type your revision, and click outside the table to save the edit.");
                JOptionPane.showMessageDialog(null, "4. Make sure to save your table before closing the program, otherwise your edits will not be saved.");
                JOptionPane.showMessageDialog(null, "5. If you want to copy a row to your report table, make sure you click the 'Disable Sort' button \n (sorting is automatically disabled when you open this program) and click on the column header with the arrow until it disappears. \n Then, select a row and click the 'Copy Row' button, then in the 'Create A Report' screen, then click 'Paste Row from Clipboard.' Save that table too!");
                JOptionPane.showMessageDialog(null, "6. To sort any of the rows, click on the column name to sort it by ascending order, and click on it again to sort it by descending order");
                JOptionPane.showMessageDialog(null, "7. If you cannot read all the letters in a cell, \n you can hover your mouse over the gridline of the column containing the data you want to read until it becomes a horizontal two-way arrow, \n then drag it to make the column wider or thinner.");
                JOptionPane.showMessageDialog(null, "8. If you want to go to another table, click one of the buttons on the left-hand side, or if you want to change accounts, click the 'Log out' button and log into your desired account.");
                JOptionPane.showMessageDialog(null, "9. Maximum of 5 accounts only!");
                JOptionPane.showMessageDialog(null, "10. If you have any questions regarding how this program works, you can email me at 'colinrondon@brent.edu.ph' ");
			}
		});
		btnGuide.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnGuide.setBounds(732, 639, 133, 45);
		contentPane.add(btnGuide);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(ChangeAccountDetails.class.getResource("/bin/horizontal line.png")));
		label.setBounds(0, 548, 140, 14);
		contentPane.add(label);
		
		JButton btnAccountDetails = new JButton("Account Details");
		btnAccountDetails.setForeground(Color.RED);
		btnAccountDetails.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		btnAccountDetails.setBackground(Color.WHITE);
		btnAccountDetails.setBounds(0, 502, 140, 41);
		contentPane.add(btnAccountDetails);
		
		JLabel lblPasssword = new JLabel("Password");
		lblPasssword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPasssword.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPasssword.setBounds(119, 337, 179, 45);
		contentPane.add(lblPasssword);
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(ChangeAccountDetails.class.getResource("/bin/horizontal line.png")));
		label_2.setBounds(0, 615, 140, 14);
		contentPane.add(label_2);
		
		JButton button = new JButton("Members List");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(membersaccess.equalsIgnoreCase("Yes")) {
					   MembersList frame = new MembersList(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
	                   frame.setVisible(true);
	                   dispose();
	                }
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		button.setForeground(Color.BLACK);
		button.setFont(new Font("Tahoma", Font.PLAIN, 14));
		button.setBackground(Color.WHITE);
		button.setBounds(0, 223, 140, 41);
		contentPane.add(button);
		
		JButton button_1 = new JButton("Attendance");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(attendanceaccess.equalsIgnoreCase("Yes")) {
					   Attendance frame = new Attendance(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
	                   frame.setVisible(true);
	                   dispose();
	                }
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		button_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		button_1.setBackground(Color.WHITE);
		button_1.setBounds(1, 298, 140, 41);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Trip Data");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tripaccess.equalsIgnoreCase("Yes")) {
					   TripData frame = new TripData(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
	                   frame.setVisible(true);
	                   dispose();
	                }
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		button_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		button_2.setBackground(Color.WHITE);
		button_2.setBounds(1, 365, 140, 41);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("CAS Credit Tracker");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(casaccess.equalsIgnoreCase("Yes")) {
					CASPointsTracker frame = new CASPointsTracker(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
					dispose();
				}
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		button_3.setForeground(Color.BLACK);
		button_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		button_3.setBackground(Color.WHITE);
		button_3.setBounds(0, 439, 140, 41);
		contentPane.add(button_3);
	}
}