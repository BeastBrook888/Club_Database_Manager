package bin;
import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JPasswordField;

public class LogInPage extends JFrame {

	private JPanel contentPane;
	private JTextField usernamefield;
	private JTextField passwordfield;
	public static String username;
	public static String password;
	public String confirmpassword;
	public int tries = 0;
	public int seconds = 10, milliseconds = 1000;
	public Timer timer;
	public int attempts = 0;
	public static DefaultTableModel dtm = new DefaultTableModel();
	public static int constant;
	private JTable table;
	
	public String firstcolumn;
	public String secondcolumn;
	public String thirdcolumn;
	public String fourthcolumn;
	public String fifthcolumn;
	public String sixthcolumn;
	public String seventhcolumn;
	
	public static String membersaccess;
	public static String attendanceaccess;
	public static String tripaccess;
	public static String accountsaccess;
	public static String casaccess;
	
	final Object[] row = new Object[7];
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LogInPage frame = new LogInPage(username, membersaccess, tripaccess, attendanceaccess, accountsaccess, casaccess);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LogInPage(String username2, String membersaccess2, String tripaccess2, String attendanceaccess2, String accountsaccess2, String casaccess2) {

		username = username2;
		membersaccess = membersaccess2;
		tripaccess = tripaccess2;
		attendanceaccess = attendanceaccess2;
		accountsaccess = accountsaccess2;
		casaccess = casaccess2;
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 25, 897, 685);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Object[] columns = {"Username", "Password", "Access ML", "Access A", "Access TD", "Access CCT", "Access AD"};
		dtm.setColumnIdentifiers(columns);
		

		try {
			File f1 = new File("UsernameAndPassword.txt"); // identifies text file
			FileReader in = new FileReader(f1); // prepares to read file
			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

			while (true) {
				firstcolumn = r.readLine();
				secondcolumn = r.readLine();
				thirdcolumn = r.readLine();
				fourthcolumn = r.readLine();
				fifthcolumn = r.readLine();
				sixthcolumn = r.readLine();
				seventhcolumn = r.readLine();
				
				if (firstcolumn == null || secondcolumn == null || thirdcolumn == null || fourthcolumn == null
						|| fifthcolumn == null || sixthcolumn == null || seventhcolumn == null) {
				
				break;
				
				}

			if(table == null) {	
				row[0] = firstcolumn;
				row[1] = secondcolumn;
				row[2] = thirdcolumn;
				row[3] = fourthcolumn;
				row[4] = fifthcolumn;
				row[5] = sixthcolumn;
				row[6] = seventhcolumn;

				dtm.addRow(row);
			  }
			}

			r.close();
		}

		catch (Exception e2) {
			System.out.println("Reading doesn't work!");
		}

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(141, 427, 438, 197);
		contentPane.add(scrollPane);
		scrollPane.setVisible(false);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(dtm);
		
		JLabel lblWaitFor = new JLabel("Please wait for __ more seconds.");
		lblWaitFor.setHorizontalAlignment(SwingConstants.CENTER);
		lblWaitFor.setForeground(Color.RED);
		lblWaitFor.setBackground(Color.BLACK);
		lblWaitFor.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblWaitFor.setBounds(-64, 488, 852, 51);
		contentPane.add(lblWaitFor);
		lblWaitFor.hide();
		
		passwordfield = new JPasswordField();
		passwordfield.setFont(new Font("Tahoma", Font.PLAIN, 40));
		passwordfield.setColumns(10);
		passwordfield.setBounds(290, 302, 575, 90);
		contentPane.add(passwordfield);

		usernamefield = new JTextField();
		usernamefield.setFont(new Font("Tahoma", Font.PLAIN, 40));
		usernamefield.setBounds(290, 154, 575, 90);
		contentPane.add(usernamefield);
		usernamefield.setColumns(10);

		JButton btnLogIn = new JButton("Log In");
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String user = usernamefield.getText();
				String pass = passwordfield.getText();
				int constant = 0;
				
					for (int i = 0; i < table.getRowCount(); i++) {// For each row
						for (int j = 0; j < table.getColumnCount(); j++) {// For each column corresponding to the row
							if (table.getValueAt(i, 0).equals(user)) {
								
								constant++;
								
								if (table.getValueAt(i, 1).equals(pass)) {
								constant++;
									JOptionPane.showMessageDialog(null, "Log-in success!");
									
									JOptionPane.showMessageDialog(null, "Welcome, " + usernamefield.getText());
									
									username = usernamefield.getText();
									
									Object one = table.getValueAt(i, 2);
									Object two = table.getValueAt(i, 3);
									Object three = table.getValueAt(i, 4);
									Object four = table.getValueAt(i, 5);
									Object five = table.getValueAt(i, 6);
									
									membersaccess = one.toString();
									attendanceaccess = two.toString();
									tripaccess = three.toString();
									accountsaccess = four.toString();
									casaccess = five.toString();
									
									MembersList frame = new MembersList(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
									frame.setVisible(true);
									dispose();
									
									break;
								}
							}
						}
					}
				
				if(constant == 0 || constant == 1) {
					JOptionPane.showMessageDialog(null, "Username or password not found! Try again!");
					tries++;
				}
					
				if (tries == 5) {
					tries = 0;
					btnLogIn.hide();
					JOptionPane.showMessageDialog(null, "Too many incorrect attempts! Try again in 10 seconds.");
					lblWaitFor.show();

					ActionListener timerListener = new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							++milliseconds;
							if (milliseconds >= 150) {
								--seconds;
								milliseconds = 0;
							}

							if (seconds <= 0) {
								lblWaitFor.hide();
								btnLogIn.show();
								seconds = 10;
								milliseconds = 1000;
							}

							lblWaitFor.setText("Please wait for " + seconds + " more seconds.");
						}
					};

					timer = new Timer(1, timerListener);
					timer.start();

				}
			}
		});
		btnLogIn.setFont(new Font("Tahoma", Font.PLAIN, 45));
		btnLogIn.setBounds(589, 427, 278, 90);
		contentPane.add(btnLogIn);

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 50));
		lblPassword.setBounds(-168, 297, 621, 90);
		contentPane.add(lblPassword);

		JLabel lblUsername = new JLabel("Username");
		lblUsername.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 50));
		lblUsername.setBounds(-168, 149, 621, 90);
		contentPane.add(lblUsername);

		JLabel lblWelcomeToKitchin = new JLabel("Welcome to Gawad Kalinga Club Data Manager!");
		lblWelcomeToKitchin.setHorizontalAlignment(SwingConstants.CENTER);
		lblWelcomeToKitchin.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblWelcomeToKitchin.setBounds(0, 0, 865, 105);
		contentPane.add(lblWelcomeToKitchin);
		
		JLabel lblPleaseEnterYour = new JLabel("Please enter your username and password below.");
		lblPleaseEnterYour.setHorizontalAlignment(SwingConstants.CENTER);
		lblPleaseEnterYour.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblPleaseEnterYour.setBounds(0, 73, 865, 90);
		contentPane.add(lblPleaseEnterYour);
	}
}
