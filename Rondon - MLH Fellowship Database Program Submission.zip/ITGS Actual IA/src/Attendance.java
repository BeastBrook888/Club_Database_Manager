package bin;

//Parameter passing for linked list containing dates for column headers of "Attendance" JFrame
//and the number of times present for "Attendance" and "CASPointsTracker" JFrame

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

//import javax.sound.sampled.Clip;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.SwingConstants;
//import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.ImageIcon;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
//import javax.swing.JTextPane;
import java.awt.datatransfer.StringSelection;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Attendance extends JFrame {

	private JPanel contentPane;
	public static DefaultTableModel dtm = new DefaultTableModel();
	public static DefaultTableModel dtm2 = new DefaultTableModel();
	public static DefaultTableModel dtm3 = new DefaultTableModel();
	Object[] row = new Object[4];
	final Object[] row2 = new Object[5];
	final Object[] row3 = new Object[4];
	public static JTable attendance;
	public static JTable memberslist;
	public static JTable tripdata;
	public static JScrollPane scrollPane_2;
	public static JScrollPane scrollPane_3;
	public static JScrollPane scrollPane_4;

	public String firstcolumn;
	public String secondcolumn;
	public String thirdcolumn;
	public String fourthcolumn;
	public String fifthcolumn;

	public static String username;
	public static String membersaccess;
	public static String attendanceaccess;
	public static String tripaccess;
	public static String accountsaccess;
	public static String casaccess;
	
	Object[] columns;

	public JTextField search;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Attendance frame = new Attendance(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	private void filter(String query) {
		TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(dtm);
		attendance.setRowSorter(tr);
		tr.setRowFilter(RowFilter.regexFilter(query));
	}
	
	public Attendance(String username2, String membersaccess2, String attendanceaccess2, String tripaccess2, String accountsaccess2, String casaccess2) {

		// Parameter passing for background variable
        username = username2;
        membersaccess = membersaccess2;
        attendanceaccess = attendanceaccess2;
        tripaccess = tripaccess2;
        accountsaccess = accountsaccess2;
        casaccess = casaccess2;
        
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 25, 897, 685);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		LinkedList<String> columnz = new LinkedList<String>();
		columnz.add("First Name");
		columnz.add("Last Name");
		columnz.add("Number of Times Present");
		

		// READ FROM FILE TO UPLOAD EXISTING DATA INTO THE TABLE
		
		Object[] columns2 = {"First Name", "Last Name", "Grade Level", "Position", "Number of Times Present"};
		dtm2.setColumnIdentifiers(columns2);

		// READ FROM FILE TO UPLOAD EXISTING DATA INTO THE TABLE
		try {
			File f1 = new File("MembersList.txt"); // identifies text file
			if (f1.createNewFile())
			{
			    System.out.println("File is created!");
			} else {
			    System.out.println("File already exists.");
			}
			FileReader in = new FileReader(f1); // prepares to read file
			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

			while (true) {

				firstcolumn = r.readLine();
				secondcolumn = r.readLine();
				thirdcolumn = r.readLine();
				fourthcolumn = r.readLine();
				fifthcolumn = r.readLine();
				
				if (firstcolumn == null || secondcolumn == null || thirdcolumn == null || fourthcolumn == null || fifthcolumn == null) {
					break;
				}

			if(memberslist == null) {	
				row2[0] = firstcolumn;
				row2[1] = secondcolumn;
				row2[2] = thirdcolumn;
				row2[3] = fourthcolumn;
				row2[4] = fifthcolumn;

				dtm2.addRow(row2);
			}

		}

			r.close();
		}

		catch (Exception e2) {
			System.out.println("Reading doesn't work!");
		}

		scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(175, 82, 698, 188);
		contentPane.add(scrollPane_3);
		scrollPane_3.hide();

		memberslist = new JTable();
		scrollPane_3.setViewportView(memberslist);
		memberslist.setModel(dtm2);
		
		Object[] columns3 = {"Event Type", "Event Date", "# of Members Present", "Notes"};
		dtm3.setColumnIdentifiers(columns3);
		
		try {
			File f1 = new File("TripMeetingData.txt");// identifies text file
			if (f1.createNewFile())
			{
			    System.out.println("File is created!");
			} else {
			    System.out.println("File already exists.");
			}
			FileReader in = new FileReader(f1); // prepares to read file
			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

			while (true) {

				firstcolumn = r.readLine();
				secondcolumn = r.readLine();
				thirdcolumn = r.readLine();
				fourthcolumn = r.readLine();
				
				if (firstcolumn == null || secondcolumn == null || thirdcolumn == null || fourthcolumn == null) {
					break;
				}

			if(tripdata == null) {	
				row3[0] = firstcolumn;
				row3[1] = secondcolumn;
				row3[2] = thirdcolumn;
				row3[3] = fourthcolumn;

				dtm3.addRow(row3);
			}

		}

			r.close();
		}

		catch (Exception e2) {
			System.out.println("Reading doesn't work!");
		}

		scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(175, 82, 698, 188);
		contentPane.add(scrollPane_4);
		scrollPane_4.hide();

		tripdata = new JTable();
		scrollPane_4.setViewportView(tripdata);
		tripdata.setModel(dtm3);
		
		for (int i = 0; i < tripdata.getRowCount(); i++) {// For each row
			    String datez = tripdata.getModel().getValueAt(i, 1).toString();
			    columnz.add(datez);
		}

		columns = columnz.toArray();
		
		 try {
	        	File f2 = new File("attendance.txt"); // identifies text file
				if (f2.createNewFile())
				{
				    System.out.println("File is created!");
				} else {
				    System.out.println("File already exists.");
				}
				FileReader in2 = new FileReader(f2); // prepares to read file
				LineNumberReader r2 = new LineNumberReader(in2); // actually reads and extracts from the file

				for(int i = 0; i < f2.length() - 1 ; i++) {	
					firstcolumn = r2.readLine();
					
					if (firstcolumn == null) {
						break;
					}
					
//					if(attendance == null) {
						row[i] = firstcolumn;
						System.out.println(firstcolumn);
							
						if(i == columnz.size() - 1) {
							dtm.addRow(row);
						}
//					}
	          }
				r2.close();
	        }
	        
	        catch (Exception e3) {
				System.out.println("Reading doesn't work!");
			}
	        
			attendance = new JTable();
			attendance.setModel(dtm);
			attendance.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			
			scrollPane_2 = new JScrollPane(attendance, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scrollPane_2.setBounds(168, 82, 705, 226);
			contentPane.add(scrollPane_2);
		
		dtm.setColumnIdentifiers(columns);
		
		JButton Delete2 = new JButton("Delete (-)");
		Delete2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int delete = JOptionPane.showConfirmDialog(null,
						"Would you like to delete your selected row/s from the table?");

				if (delete == JOptionPane.YES_OPTION) {
					int selRow = attendance.getSelectedRow();
					dtm.removeRow(selRow);
				}
			}
		});
		
		JComboBox name = new JComboBox();
		name.setMaximumRowCount(31);
		name.setFont(new Font("Tahoma", Font.BOLD, 20));
		name.setBackground(Color.WHITE);
		name.setBounds(317, 330, 210, 32);
		contentPane.add(name);
		
		JSpinner spinner = new JSpinner();
		spinner.setFont(new Font("Tahoma", Font.BOLD, 30));
		spinner.setBounds(388, 380, 133, 34);
		contentPane.add(spinner);
		
		for (int i = 0; i < memberslist.getRowCount(); i++) {
			Object firstnamee = memberslist.getValueAt(i, 0);
		    Object lastnamee = memberslist.getValueAt(i, 1);
		    
		    String firstnameee = firstnamee.toString();
		    String lastnameee = lastnamee.toString();
			
			name.addItem(firstnameee + " " + lastnameee);
		}
		
		JButton btnAdd = new JButton("Add (+)");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object namez = name.getSelectedItem();
				String namezz = namez.toString();
				
				String[] arrSplit = namezz.split(" ");
			    
				String firstname = arrSplit[0].toString();
				//Currently doesn't work with surnames with more than 1 word
				String lastname = arrSplit[1].toString();
				
				Object six = spinner.getValue();
				String presentvalue = six.toString();
				
				int match = 0;
				
				for(int i = 0; i < attendance.getRowCount(); i++) {
					for(int j = 0; j < attendance.getColumnCount(); j++) {
						if(attendance.getValueAt(i, 0).equals(namez)) {
							JOptionPane.showMessageDialog(null, "This name is already found in this table.");
						    match++;
						}
					}
				}
				
			if(match == 0) {	
				int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you would like to add this entry to the table?");
				
				if(confirm == JOptionPane.YES_OPTION) {
					row[0] = firstname;
					row[1] = lastname;
					row[2] = presentvalue;
					
					dtm.addRow(row);
				}
			  }
			}
		});
		btnAdd.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAdd.setBounds(196, 578, 133, 45);
		contentPane.add(btnAdd);
		Delete2.setFont(new Font("Tahoma", Font.BOLD, 11));
		Delete2.setBounds(355, 578, 133, 45);
		contentPane.add(Delete2);

		JButton Save2 = new JButton("Save");
		Save2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int save = JOptionPane.showConfirmDialog(null, "Are you sure you would like to save your employee data table?");
				
				if(save == JOptionPane.YES_OPTION) {
				
					int numOfRows = dtm.getRowCount();

					try {
						File f = new File("attendance.txt"); // creates text file
						FileOutputStream in = new FileOutputStream(f); // prepares text file for printing
						PrintWriter w = new PrintWriter(in); // allows for text file to be printed

						for (int x = 0; x < numOfRows; x++) {
							for (int y = 0; y < columnz.size(); y++) {
								w.println((String) dtm.getValueAt(x, y));
							}
						}

						w.close();
						JOptionPane.showMessageDialog(null, "Your data has been saved.");
					}

					catch (Exception e2) {
                         System.out.println("Saving doesn't work!");
					}	
				}
			}
		});
		Save2.setFont(new Font("Tahoma", Font.BOLD, 11));
		Save2.setBounds(521, 578, 126, 45);
		contentPane.add(Save2);

		search = new JTextField();
		search.setHorizontalAlignment(SwingConstants.CENTER);
		search.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				String query = search.getText();
				filter(query);
			}
		});
		search.setFont(new Font("Tahoma", Font.BOLD, 14));
		search.setColumns(10);
		search.setBounds(421, 41, 452, 30);
		contentPane.add(search);
		
		JLabel lblEmployeeData = new JLabel("Attendance");
		lblEmployeeData.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmployeeData.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblEmployeeData.setBounds(150, -9, 733, 45);
		contentPane.add(lblEmployeeData);
		
		JLabel label_9 = new JLabel("");
		label_9.setIcon(new ImageIcon(Attendance.class.getResource("vertical line.png")));
		label_9.setBounds(138, -34, 19, 710);
		contentPane.add(label_9);
		
		JLabel label_10 = new JLabel("");
		label_10.setIcon(new ImageIcon(Attendance.class.getResource("horizontal line.png")));
		label_10.setBounds(-2, 165, 140, 14);
		contentPane.add(label_10);
		
		JButton EmployeeDataButton = new JButton("Members List");
		EmployeeDataButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(membersaccess.equalsIgnoreCase("Yes")) {
					   MembersList frame = new MembersList(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
	                   frame.setVisible(true);
	                   dispose();
	                }
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		EmployeeDataButton.setForeground(Color.BLACK);
		EmployeeDataButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		EmployeeDataButton.setBackground(Color.WHITE);
		EmployeeDataButton.setBounds(-2, 188, 140, 41);
		contentPane.add(EmployeeDataButton);
		
		JLabel label_11 = new JLabel("Current Account:");
		label_11.setHorizontalAlignment(SwingConstants.CENTER);
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_11.setBounds(0, 0, 140, 45);
		contentPane.add(label_11);
		
		JLabel label_12 = new JLabel("");
		label_12.setIcon(new ImageIcon(Attendance.class.getResource("/bin/horizontal line.png")));
		label_12.setBounds(-2, 227, 140, 14);
		contentPane.add(label_12);
		
		JButton OTDataButton = new JButton("Trip Data");
		OTDataButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tripaccess.equalsIgnoreCase("Yes")) {	
					TripData frame = new TripData(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
					dispose();
			    }
			
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		OTDataButton.setBackground(Color.WHITE);
		OTDataButton.setBounds(-2, 319, 140, 41);
		contentPane.add(OTDataButton);
		
		JLabel label_13 = new JLabel("");
		label_13.setIcon(new ImageIcon(Attendance.class.getResource("/bin/horizontal line.png")));
		label_13.setBounds(-2, 299, 140, 14);
		contentPane.add(label_13);
		
		JButton btnAttendance = new JButton("Attendance");
		btnAttendance.setForeground(Color.RED);
		btnAttendance.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		btnAttendance.setBackground(Color.WHITE);
		btnAttendance.setBounds(-2, 252, 140, 41);
		contentPane.add(btnAttendance);
		
		JButton button_8 = new JButton("Log Out");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 int logout = JOptionPane.showConfirmDialog(null, "Would you like to log out of your account?");
					
					if(logout == JOptionPane.YES_OPTION) {
						LogInPage frame = new LogInPage(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
						frame.setVisible(true);
						dispose();
					}
			}
		});
		button_8.setBackground(Color.WHITE);
		button_8.setBounds(0, 528, 140, 41);
		contentPane.add(button_8);
		
		JLabel label_15 = new JLabel("");
		label_15.setIcon(new ImageIcon(Attendance.class.getResource("/bin/horizontal line.png")));
		label_15.setBounds(0, 440, 140, 14);
		contentPane.add(label_15);
		
		JButton button_9 = new JButton("Close Program");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                int exit = JOptionPane.showConfirmDialog(null, "Would you like to close the program?");
				
				if(exit == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
		button_9.setBackground(Color.WHITE);
		button_9.setBounds(0, 596, 140, 41);
		contentPane.add(button_9);
		
		JLabel label_16 = new JLabel("");
		label_16.setIcon(new ImageIcon(Attendance.class.getResource("/bin/horizontal line.png")));
		label_16.setBounds(-2, 371, 140, 14);
		contentPane.add(label_16);
		
		JLabel label_17 = new JLabel("________");
		label_17.setHorizontalAlignment(SwingConstants.CENTER);
		label_17.setFont(new Font("Tahoma", Font.BOLD, 12));
		label_17.setBounds(0, 48, 140, 45);
		contentPane.add(label_17);
		label_17.setText(username);
		
		JButton btnGuide = new JButton("Instructions");
		btnGuide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "1. Fill out all the text fields below the table, especially the blank text fields.");
                JOptionPane.showMessageDialog(null, "2. To delete a row, select (click on) any row, and click the 'Delete' button.");
                JOptionPane.showMessageDialog(null, "3. To edit the data in a cell, double click it, type your revision, and click outside the table to save the edit.");
                JOptionPane.showMessageDialog(null, "4. Make sure to save your table before closing the program, otherwise your edits will not be saved.");
                JOptionPane.showMessageDialog(null, "5. If you want to copy a row to your report table, make sure you click the 'Disable Sort' button \n (sorting is automatically disabled when you open this program) and click on the column header with the arrow until it disappears. \n Then, select a row and click the 'Copy Row' button, then in the 'Create A Report' screen, then click 'Paste Row from Clipboard.' Save that table too!");
                JOptionPane.showMessageDialog(null, "6. You can search for a word/s in the table by typing in the text field above the table and beside the 'Search' button. \n Click that button, and the table will show results matching what you typed in the text field \n (make sure to match the casing of the word you are looking for). \n To show all your table entries again, delete all text from the text field and click the 'Search' button.");
                JOptionPane.showMessageDialog(null, "7. To sort any of the rows, click on the column name to sort it by ascending order, and click on it again to sort it by descending order");
                JOptionPane.showMessageDialog(null, "8. If you cannot read all the letters in a cell, \n you can hover your mouse over the gridline of the column containing the data you want to read until it becomes a horizontal two-way arrow, \n then drag it to make the column wider or thinner.");
                JOptionPane.showMessageDialog(null, "9. If you want to go to another table, click one of the buttons on the left-hand side, or if you want to change accounts, click the 'Log out' button and log into your desired account.");
                JOptionPane.showMessageDialog(null, "10. If you have any questions regarding how this program works, you can email me at 'colinrondon@brent.edu.ph' ");
			}
		});
		btnGuide.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnGuide.setBounds(740, 578, 133, 45);
		contentPane.add(btnGuide);
		
		JButton btnRemoveSort = new JButton("Enable Sort");
		btnRemoveSort.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(attendance.getModel());
				attendance.setRowSorter(sorter);
				
				List<RowSorter.SortKey> sortKeys = new ArrayList<>(25);
				sorter.setSortKeys(sortKeys);
				
			}
		});
		btnRemoveSort.setBounds(740, 346, 133, 23);
		contentPane.add(btnRemoveSort);
		
		JButton button = new JButton("Disable Sort");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				attendance.setRowSorter(null);
				
			}
		});
		button.setBounds(740, 375, 133, 23);
		contentPane.add(button);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(ChangeAccountDetails.class.getResource("/bin/horizontal line.png")));
		label.setBounds(0, 506, 140, 14);
		contentPane.add(label);
		
		JButton btnAccountDetails = new JButton("Account Details");
		btnAccountDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(accountsaccess.equalsIgnoreCase("Yes")) {
					ChangeAccountDetails frame = new ChangeAccountDetails(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
				    frame.setVisible(true);
				    dispose();
				}
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
				
			}
		});
		btnAccountDetails.setBackground(Color.WHITE);
		btnAccountDetails.setBounds(0, 461, 140, 41);
		contentPane.add(btnAccountDetails);
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(Attendance.class.getResource("/bin/horizontal line.png")));
		label_2.setBounds(0, 573, 140, 14);
		contentPane.add(label_2);
		
		JButton btnCasCreditTracker = new JButton("CAS Credit Tracker");
		btnCasCreditTracker.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(casaccess.equalsIgnoreCase("Yes")) {
					CASPointsTracker frame = new CASPointsTracker(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
					dispose();
				}
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		btnCasCreditTracker.setForeground(Color.BLACK);
		btnCasCreditTracker.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btnCasCreditTracker.setBackground(Color.WHITE);
		btnCasCreditTracker.setBounds(-3, 393, 140, 41);
		contentPane.add(btnCasCreditTracker);
		
		JLabel lblTypeYourSearch = new JLabel("Type your search term in here ->");
		lblTypeYourSearch.setHorizontalAlignment(SwingConstants.CENTER);
		lblTypeYourSearch.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTypeYourSearch.setBounds(148, 30, 276, 45);
		contentPane.add(lblTypeYourSearch);
		
		JLabel label_1 = new JLabel("First & Last Name");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		label_1.setBounds(150, 324, 179, 45);
		contentPane.add(label_1);
		
		JLabel label_3 = new JLabel("Number of Times Present");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		label_3.setBounds(164, 373, 211, 45);
		contentPane.add(label_3);
		
		JButton button_1 = new JButton("Create New File");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int filecreation = JOptionPane.showConfirmDialog(null, "Are you sure you would like to make the current table a new .txt file?");
				
				if(filecreation == JOptionPane.YES_OPTION) {
					String filename = JOptionPane.showInputDialog("Type a name for the .txt file");
					int numOfRows = dtm.getRowCount();
					try {
						File f1 = new File(filename + ".txt"); // identifies text file
						if (f1.createNewFile())
						{
							FileOutputStream in = new FileOutputStream(f1); // prepares text file for printing
							PrintWriter w = new PrintWriter(in); // allows for text file to be printed

							for (int x = 0; x < numOfRows; x++) {
								for (int y = 0; y < 5; y++) {
									w.println((String) dtm.getValueAt(x, y));
								}
							}

							w.close();
							JOptionPane.showMessageDialog(null, "Your data has been saved.");
							System.out.println("File is created!");
						} else {
						    System.out.println("File already exists.");
						}
					}
					
					catch (Exception e2) {
						System.out.println("File could not be created or process did not work");
					}
				}
			}
		});
		button_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		button_1.setBounds(704, 428, 179, 45);
		contentPane.add(button_1);
		
		JButton btnPastepInto = new JButton("Paste \"P\" in Selected Cell");
		btnPastepInto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selRow = attendance.getSelectedRow();
				int selColumn = attendance.getSelectedColumn();
				
				attendance.setValueAt("P", selRow, selColumn);
			}
		});
		btnPastepInto.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnPastepInto.setBounds(162, 457, 262, 45);
		contentPane.add(btnPastepInto);
		
		JButton btnPastenpInto = new JButton("Paste \"NP\" in Selected Cell");
		btnPastenpInto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int selRow = attendance.getSelectedRow();
				int selColumn = attendance.getSelectedColumn();
				
				attendance.setValueAt("NP", selRow, selColumn);
				
			}
		});
		btnPastenpInto.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnPastenpInto.setBounds(436, 457, 248, 45);
		contentPane.add(btnPastenpInto);
		
//		JButton btnReadAnotherFile = new JButton("Read Another File");
//		btnReadAnotherFile.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				  FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
//                  fc.setFileFilter(filter);
//	              int returnVal = fc.showOpenDialog(null);
//	              File selectedFile = null;
//	              if(returnVal == JFileChooser.APPROVE_OPTION)
//	              {
//	                  selectedFile = fc.getSelectedFile();
//	                  String filename = selectedFile.getAbsolutePath();
//	                  String actualfilename = filename.substring(filename.lastIndexOf("\\")+1);
//	                  
//	                  if(selectedFile.getName().toLowerCase().endsWith(".txt")) {
//	                	 dtm.setRowCount(0);
//	                	  try {
//	              			File f1 = new File(actualfilename); // identifies text file
//	              			System.out.println(actualfilename);
//	              			FileReader in = new FileReader(f1); // prepares to read file
//	              			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file
//
//	              			while (true) {
//	              				firstcolumn = r.readLine();
//	              				secondcolumn = r.readLine();
//	              				thirdcolumn = r.readLine();
//	              				fourthcolumn = r.readLine();
//	              				
//	              				if (firstcolumn == null || secondcolumn == null || thirdcolumn == null || fourthcolumn == null) {
//	              					break;
//	              				}
//
//	              				row[0] = firstcolumn;
//	              				row[1] = secondcolumn;
//	              				row[2] = thirdcolumn;
//	              				row[3] = fourthcolumn;
//
//	              				dtm.addRow(row);
//	              			
//	              		}
//
//	              			r.close();
//	              		}
//
//	              		catch (Exception e2) {
//	              			System.out.println("Reading doesn't work!");
//	              		}
//
//	                  }
//            			scrollPane_2.setViewportView(attendance);
//            			attendance.setModel(dtm);
//            			contentPane.add(scrollPane_2);
//	              } 
//			}
//		});
//		btnReadAnotherFile.setFont(new Font("Tahoma", Font.BOLD, 15));
//		btnReadAnotherFile.setBounds(639, 506, 204, 54);
//		contentPane.add(btnReadAnotherFile);
   }	
}