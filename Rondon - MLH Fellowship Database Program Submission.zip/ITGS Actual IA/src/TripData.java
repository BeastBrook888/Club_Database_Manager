package bin;

//Parameter passing for linked list containing dates for column headers of "Attendance" JFrame
//and the number of times present for "Attendance" and "CASPointsTracker" JFrame

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

//import javax.sound.sampled.Clip;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.SwingConstants;
//import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.ImageIcon;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
//import javax.swing.JTextPane;
import java.awt.datatransfer.StringSelection;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JTextArea;

public class TripData extends JFrame {

	private JPanel contentPane;
	public static DefaultTableModel dtm = new DefaultTableModel();
	final Object[] row = new Object[4];
	public static JTable tripdata;
	public static JScrollPane scrollPane_2;

	public String firstcolumn;
	public String secondcolumn;
	public String thirdcolumn;
	public String fourthcolumn;

	public static String username;
	public static String membersaccess;
	public static String attendanceaccess;
	public static String tripaccess;
	public static String accountsaccess;
	public static String casaccess;
	
    public static LinkedList dates;

	public JTextField search;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TripData frame = new TripData(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	private void filter(String query) {
		TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(dtm);
		tripdata.setRowSorter(tr);
		tr.setRowFilter(RowFilter.regexFilter(query));
	}
	
	public TripData(String username2, String membersaccess2, String attendanceaccess2, String tripaccess2, String accountsaccess2, String casaccess2) {

		// Parameter passing for background variable
        username = username2;
        membersaccess = membersaccess2;
        attendanceaccess = attendanceaccess2;
        tripaccess = tripaccess2;
        accountsaccess = accountsaccess2;
        casaccess = casaccess2;
        
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 25, 897, 685);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		Object[] columns = {"Event Type", "Event Date", "# of Members Present", "Notes"};
		dtm.setColumnIdentifiers(columns);

		// READ FROM FILE TO UPLOAD EXISTING DATA INTO THE TABLE
		try {
			File f1 = new File("TripMeetingData.txt");// identifies text file
			if (f1.createNewFile())
			{
			    System.out.println("File is created!");
			} else {
			    System.out.println("File already exists.");
			}
			FileReader in = new FileReader(f1); // prepares to read file
			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

			while (true) {

				firstcolumn = r.readLine();
				secondcolumn = r.readLine();
				thirdcolumn = r.readLine();
				fourthcolumn = r.readLine();
				
				if (firstcolumn == null || secondcolumn == null || thirdcolumn == null || fourthcolumn == null) {
					break;
				}

			if(tripdata == null) {	
				row[0] = firstcolumn;
				row[1] = secondcolumn;
				row[2] = thirdcolumn;
				row[3] = fourthcolumn;

				dtm.addRow(row);
			}

		}

			r.close();
		}

		catch (Exception e2) {
			System.out.println("Reading doesn't work!");
		}

		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(175, 82, 698, 188);
		contentPane.add(scrollPane_2);

		tripdata = new JTable();
		scrollPane_2.setViewportView(tripdata);
		tripdata.setModel(dtm);
		
        LinkedList<String> date1 = new LinkedList<String>();
		
		for (int i = 0; i < tripdata.getRowCount(); i++) {// For each row
			for (int j = 0; j < tripdata.getColumnCount(); j++) {// For each column corresponding to the row
			    	String datez = tripdata.getModel().getValueAt(i, 1).toString();
			    	
			    	date1.add(datez);
			    	
			    	dates = date1;
			   }
			}
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBackground(Color.WHITE);
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 23));
		comboBox.setMaximumRowCount(12);
		comboBox.setBounds(314, 281, 276, 32);
		contentPane.add(comboBox);
		comboBox.addItem(new ITGSIAComboItem("Officers Meeting", "1"));
		comboBox.addItem(new ITGSIAComboItem("Full Club Meeting", "2"));
		comboBox.addItem(new ITGSIAComboItem("Trip", "3"));
		
		JComboBox Month2 = new JComboBox();
		Month2.setBackground(Color.WHITE);
		Month2.setFont(new Font("Tahoma", Font.BOLD, 15));
		Month2.setMaximumRowCount(12);
		Month2.setBounds(316, 324, 135, 32);
		contentPane.add(Month2);
		Month2.addItem(new ITGSIAComboItem("January", "1"));
		Month2.addItem(new ITGSIAComboItem("February", "2"));
		Month2.addItem(new ITGSIAComboItem("March", "3"));
		Month2.addItem(new ITGSIAComboItem("April", "4"));
		Month2.addItem(new ITGSIAComboItem("May", "5"));
		Month2.addItem(new ITGSIAComboItem("June", "6"));
		Month2.addItem(new ITGSIAComboItem("July", "7"));
		Month2.addItem(new ITGSIAComboItem("August", "8"));
		Month2.addItem(new ITGSIAComboItem("September", "9"));
		Month2.addItem(new ITGSIAComboItem("October", "10"));
		Month2.addItem(new ITGSIAComboItem("November", "11"));
		Month2.addItem(new ITGSIAComboItem("December", "12"));

		JComboBox Date2 = new JComboBox();
		Date2.setBackground(Color.WHITE);
		Date2.setFont(new Font("Tahoma", Font.BOLD, 20));
		Date2.setMaximumRowCount(31);
		Date2.setBounds(460, 324, 50, 32);
		contentPane.add(Date2);
		for (int i = 1; i < 32; i++) {
			Date2.addItem(i);
		}
		
		JTextField year = new JTextField();
		year.setFont(new Font("Tahoma", Font.BOLD, 15));
		year.setText("2020");
		year.setColumns(10);
		year.setBounds(520, 323, 140, 35);
		contentPane.add(year);
		
		JSpinner spinner_3 = new JSpinner();
		spinner_3.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
		spinner_3.setFont(new Font("Tahoma", Font.BOLD, 30));
		spinner_3.setBounds(407, 367, 133, 34);
		contentPane.add(spinner_3);

		JTextArea notes = new JTextArea();
		notes.setWrapStyleWord(true);
		notes.setBounds(154, 443, 464, 138);
		contentPane.add(notes);
		notes.setLineWrap(true);
		
		JButton Add2 = new JButton("Add (+)");
		Add2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Object monthh = Month2.getSelectedItem();
				Object datee = Date2.getSelectedItem();
				String yearr = year.getText();
				String notess = notes.getText();
			
				Object four = comboBox.getSelectedItem();
				Object six = spinner_3.getValue();

				String eight = six.toString();
				String nine = four.toString();
				String convert1 = monthh.toString();
				String convert2 = datee.toString();
				String convert3 = yearr.toString();
				
				if (yearr.isBlank() == false) {
					
				int add = JOptionPane.showConfirmDialog(null, "Would you like to add this entry to your table?");
					
				if(add == JOptionPane.YES_OPTION) {
					row[0] = nine;
					row[1] = convert1 + " " + convert2 + ", " + convert3;
					row[2] = eight;
					row[3] = notess;

					dtm.addRow(row);
				   }
				}	
			}
		});
		Add2.setFont(new Font("Tahoma", Font.BOLD, 11));
		Add2.setBounds(175, 592, 133, 45);
		contentPane.add(Add2);

		JButton Delete2 = new JButton("Delete (-)");
		Delete2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int delete = JOptionPane.showConfirmDialog(null,
						"Would you like to delete your selected row/s from the table?");

				if (delete == JOptionPane.YES_OPTION) {
					int selRow = tripdata.getSelectedRow();
					dtm.removeRow(selRow);
				}
			}
		});
		Delete2.setFont(new Font("Tahoma", Font.BOLD, 11));
		Delete2.setBounds(348, 592, 133, 45);
		contentPane.add(Delete2);

		JButton Save2 = new JButton("Save");
		Save2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int save = JOptionPane.showConfirmDialog(null, "Are you sure you would like to save your employee data table?");
				
				if(save == JOptionPane.YES_OPTION) {
				
					int numOfRows = dtm.getRowCount();

					try {
						File f = new File("TripMeetingData.txt"); // creates text file
						FileOutputStream in = new FileOutputStream(f); // prepares text file for printing
						PrintWriter w = new PrintWriter(in); // allows for text file to be printed

						for (int x = 0; x < numOfRows; x++) {
							for (int y = 0; y < 4; y++) {
								w.println((String) dtm.getValueAt(x, y));
							}
						}

						w.close();
						JOptionPane.showMessageDialog(null, "Your employee data has been saved.");
					}

					catch (Exception e2) {
                         System.out.println("Saving doesn't work!");
					}	
				}
			}
		});
		Save2.setFont(new Font("Tahoma", Font.BOLD, 11));
		Save2.setBounds(514, 592, 126, 45);
		contentPane.add(Save2);

		JLabel lblPosition = new JLabel("Event Type");
		lblPosition.setHorizontalAlignment(SwingConstants.LEFT);
		lblPosition.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPosition.setBounds(154, 271, 179, 45);
		contentPane.add(lblPosition);

		JLabel lblOfOts = new JLabel("Number of Members Present");
		lblOfOts.setHorizontalAlignment(SwingConstants.LEFT);
		lblOfOts.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblOfOts.setBounds(154, 368, 239, 45);
		contentPane.add(lblOfOts);

		search = new JTextField();
		search.setHorizontalAlignment(SwingConstants.CENTER);
		search.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				String query = search.getText();
				filter(query);
			}
		});
		search.setFont(new Font("Tahoma", Font.BOLD, 14));
		search.setColumns(10);
		search.setBounds(421, 41, 452, 30);
		contentPane.add(search);
		
		JLabel lblEmployeeData = new JLabel("Trips & Meetings Data");
		lblEmployeeData.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmployeeData.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblEmployeeData.setBounds(150, -9, 733, 45);
		contentPane.add(lblEmployeeData);
		
		JLabel label_9 = new JLabel("");
		label_9.setIcon(new ImageIcon(TripData.class.getResource("vertical line.png")));
		label_9.setBounds(138, -34, 19, 710);
		contentPane.add(label_9);
		
		JLabel label_10 = new JLabel("");
		label_10.setIcon(new ImageIcon(TripData.class.getResource("horizontal line.png")));
		label_10.setBounds(-2, 165, 140, 14);
		contentPane.add(label_10);
		
		JButton EmployeeDataButton = new JButton("Members List");
		EmployeeDataButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                if(membersaccess.equalsIgnoreCase("Yes")) {
				   MembersList frame = new MembersList(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
                   frame.setVisible(true);
                   dispose();
                }  
                
                else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		EmployeeDataButton.setForeground(Color.BLACK);
		EmployeeDataButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		EmployeeDataButton.setBackground(Color.WHITE);
		EmployeeDataButton.setBounds(-2, 188, 140, 41);
		contentPane.add(EmployeeDataButton);
		
		JLabel label_11 = new JLabel("Current Account:");
		label_11.setHorizontalAlignment(SwingConstants.CENTER);
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_11.setBounds(0, 0, 140, 45);
		contentPane.add(label_11);
		
		JLabel label_12 = new JLabel("");
		label_12.setIcon(new ImageIcon(TripData.class.getResource("/bin/horizontal line.png")));
		label_12.setBounds(-2, 227, 140, 14);
		contentPane.add(label_12);
		
		JButton OTDataButton = new JButton("Trip Data");
		OTDataButton.setForeground(Color.RED);
		OTDataButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		OTDataButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				    if(tripaccess.equalsIgnoreCase("Yes")) {
					   TripData frame = new TripData(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
	                   frame.setVisible(true);
	                   dispose();
	                } 
				    
				    else {
						JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
					}
			}
		});
		OTDataButton.setBackground(Color.WHITE);
		OTDataButton.setBounds(-2, 319, 140, 41);
		contentPane.add(OTDataButton);
		
		JLabel label_13 = new JLabel("");
		label_13.setIcon(new ImageIcon(TripData.class.getResource("/bin/horizontal line.png")));
		label_13.setBounds(-2, 299, 140, 14);
		contentPane.add(label_13);
		
		JButton btnAttendance = new JButton("Attendance");
		btnAttendance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				    if(attendanceaccess.equalsIgnoreCase("Yes")) {
					   Attendance frame = new Attendance(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
	                   frame.setVisible(true);
	                   dispose();
	                }
				    
				    else {
						JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
					}
			}
		});
		btnAttendance.setBackground(Color.WHITE);
		btnAttendance.setBounds(-2, 252, 140, 41);
		contentPane.add(btnAttendance);
		
		JButton button_8 = new JButton("Log Out");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 int logout = JOptionPane.showConfirmDialog(null, "Would you like to log out of your account?");
					
					if(logout == JOptionPane.YES_OPTION) {
						LogInPage frame = new LogInPage(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
						frame.setVisible(true);
						dispose();
					}
			}
		});
		button_8.setBackground(Color.WHITE);
		button_8.setBounds(0, 528, 140, 41);
		contentPane.add(button_8);
		
		JLabel label_15 = new JLabel("");
		label_15.setIcon(new ImageIcon(TripData.class.getResource("/bin/horizontal line.png")));
		label_15.setBounds(0, 440, 140, 14);
		contentPane.add(label_15);
		
		JButton button_9 = new JButton("Close Program");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                int exit = JOptionPane.showConfirmDialog(null, "Would you like to close the program?");
				
				if(exit == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
		button_9.setBackground(Color.WHITE);
		button_9.setBounds(0, 596, 140, 41);
		contentPane.add(button_9);
		
		JLabel label_16 = new JLabel("");
		label_16.setIcon(new ImageIcon(TripData.class.getResource("/bin/horizontal line.png")));
		label_16.setBounds(-2, 371, 140, 14);
		contentPane.add(label_16);
		
		JLabel label_17 = new JLabel("________");
		label_17.setHorizontalAlignment(SwingConstants.CENTER);
		label_17.setFont(new Font("Tahoma", Font.BOLD, 12));
		label_17.setBounds(0, 48, 140, 45);
		contentPane.add(label_17);
		label_17.setText(username);
		
		JButton btnGuide = new JButton("Instructions");
		btnGuide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "1. Fill out all the text fields below the table, especially the blank text fields.");
                JOptionPane.showMessageDialog(null, "2. To delete a row, select (click on) any row, and click the 'Delete' button.");
                JOptionPane.showMessageDialog(null, "3. To edit the data in a cell, double click it, type your revision, and click outside the table to save the edit.");
                JOptionPane.showMessageDialog(null, "4. Make sure to save your table before closing the program, otherwise your edits will not be saved.");
                JOptionPane.showMessageDialog(null, "5. If you want to copy a row to your report table, make sure you click the 'Disable Sort' button \n (sorting is automatically disabled when you open this program) and click on the column header with the arrow until it disappears. \n Then, select a row and click the 'Copy Row' button, then in the 'Create A Report' screen, then click 'Paste Row from Clipboard.' Save that table too!");
                JOptionPane.showMessageDialog(null, "6. You can search for a word/s in the table by typing in the text field above the table and beside the 'Search' button. \n Click that button, and the table will show results matching what you typed in the text field \n (make sure to match the casing of the word you are looking for). \n To show all your table entries again, delete all text from the text field and click the 'Search' button.");
                JOptionPane.showMessageDialog(null, "7. To sort any of the rows, click on the column name to sort it by ascending order, and click on it again to sort it by descending order");
                JOptionPane.showMessageDialog(null, "8. If you cannot read all the letters in a cell, \n you can hover your mouse over the gridline of the column containing the data you want to read until it becomes a horizontal two-way arrow, \n then drag it to make the column wider or thinner.");
                JOptionPane.showMessageDialog(null, "9. If you want to go to another table, click one of the buttons on the left-hand side, or if you want to change accounts, click the 'Log out' button and log into your desired account.");
                JOptionPane.showMessageDialog(null, "10. If you have any questions regarding how this program works, you can email me at 'colinrondon@brent.edu.ph' ");
			}
		});
		btnGuide.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnGuide.setBounds(740, 592, 133, 45);
		contentPane.add(btnGuide);
		
		JButton btnRemoveSort = new JButton("Enable Sort");
		btnRemoveSort.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(tripdata.getModel());
				tripdata.setRowSorter(sorter);
				
				List<RowSorter.SortKey> sortKeys = new ArrayList<>(25);
				sorter.setSortKeys(sortKeys);
				
			}
		});
		btnRemoveSort.setBounds(740, 337, 133, 23);
		contentPane.add(btnRemoveSort);
		
		JButton button = new JButton("Disable Sort");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tripdata.setRowSorter(null);
			}
		});
		button.setBounds(740, 366, 133, 23);
		contentPane.add(button);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(ChangeAccountDetails.class.getResource("/bin/horizontal line.png")));
		label.setBounds(0, 506, 140, 14);
		contentPane.add(label);
		
		JButton btnAccountDetails = new JButton("Account Details");
		btnAccountDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if(accountsaccess.equalsIgnoreCase("Yes")) {
					   ChangeAccountDetails frame = new ChangeAccountDetails(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
	                   frame.setVisible(true);
	                   dispose();
	                }
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
				
			}
		});
		btnAccountDetails.setBackground(Color.WHITE);
		btnAccountDetails.setBounds(0, 461, 140, 41);
		contentPane.add(btnAccountDetails);
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(TripData.class.getResource("/bin/horizontal line.png")));
		label_2.setBounds(0, 573, 140, 14);
		contentPane.add(label_2);
		
		JButton btnCasCreditTracker = new JButton("CAS Credit Tracker");
		btnCasCreditTracker.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(casaccess.equalsIgnoreCase("Yes")) {
					CASPointsTracker frame = new CASPointsTracker(username, membersaccess, attendanceaccess, tripaccess, accountsaccess, casaccess);
					frame.setVisible(true);
					dispose();
				}
				
				else {
					JOptionPane.showMessageDialog(null, "Sorry, but you cannot access this screen!");
				}
			}
		});
		btnCasCreditTracker.setForeground(Color.BLACK);
		btnCasCreditTracker.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btnCasCreditTracker.setBackground(Color.WHITE);
		btnCasCreditTracker.setBounds(-3, 393, 140, 41);
		contentPane.add(btnCasCreditTracker);
		
		JLabel lblTypeYourSearch = new JLabel("Type your search term in here ->");
		lblTypeYourSearch.setHorizontalAlignment(SwingConstants.CENTER);
		lblTypeYourSearch.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTypeYourSearch.setBounds(148, 30, 276, 45);
		contentPane.add(lblTypeYourSearch);
		
		JLabel lblTripmeetingDate = new JLabel("Event Date");
		lblTripmeetingDate.setHorizontalAlignment(SwingConstants.LEFT);
		lblTripmeetingDate.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTripmeetingDate.setBounds(156, 320, 179, 45);
		contentPane.add(lblTripmeetingDate);
		
		JLabel lblMeetingNotesgoalsAccomplished = new JLabel("Meeting Notes/Goals Accomplished");
		lblMeetingNotesgoalsAccomplished.setHorizontalAlignment(SwingConstants.LEFT);
		lblMeetingNotesgoalsAccomplished.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblMeetingNotesgoalsAccomplished.setBounds(156, 406, 289, 45);
		contentPane.add(lblMeetingNotesgoalsAccomplished);
		
		JButton button_1 = new JButton("Create New File");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int filecreation = JOptionPane.showConfirmDialog(null, "Are you sure you would like to make the current table a new .txt file?");
				
				if(filecreation == JOptionPane.YES_OPTION) {
					String filename = JOptionPane.showInputDialog("Type a name for the .txt file");
					int numOfRows = dtm.getRowCount();
					try {
						File f1 = new File(filename + ".txt"); // identifies text file
						if (f1.createNewFile())
						{
							FileOutputStream in = new FileOutputStream(f1); // prepares text file for printing
							PrintWriter w = new PrintWriter(in); // allows for text file to be printed

							for (int x = 0; x < numOfRows; x++) {
								for (int y = 0; y < 4; y++) {
									w.println((String) dtm.getValueAt(x, y));
								}
							}

							w.close();
							JOptionPane.showMessageDialog(null, "Your data has been saved.");
							System.out.println("File is created!");
						} else {
						    System.out.println("File already exists.");
						}
					}
					
					catch (Exception e2) {
						System.out.println("File could not be created or process did not work");
					}
				}
			}
		});
		button_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		button_1.setBounds(658, 440, 179, 45);
		contentPane.add(button_1);
		
		JButton btnReadAnotherFile = new JButton("Read Another File");
		btnReadAnotherFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  JFileChooser fc = new JFileChooser();
				  FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
		          fc.setFileFilter(filter);
	              int returnVal = fc.showOpenDialog(null);
	              File selectedFile = null;
	              if(returnVal == JFileChooser.APPROVE_OPTION)
	              {
	                  selectedFile = fc.getSelectedFile();
	                  String filename = selectedFile.getAbsolutePath();
	                  String actualfilename = filename.substring(filename.lastIndexOf("\\")+1);
	                  
	                  if(selectedFile.getName().toLowerCase().endsWith(".txt")) {
	                	 dtm.setRowCount(0);
	                	  try {
	              			File f1 = new File(actualfilename); // identifies text file
	              			System.out.println(actualfilename);
	              			FileReader in = new FileReader(f1); // prepares to read file
	              			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

	              			while (true) {
	              				firstcolumn = r.readLine();
	              				secondcolumn = r.readLine();
	              				thirdcolumn = r.readLine();
	              				fourthcolumn = r.readLine();
	              				
	              				if (firstcolumn == null || secondcolumn == null || thirdcolumn == null || fourthcolumn == null) {
	              					break;
	              				}

	              				row[0] = firstcolumn;
	              				row[1] = secondcolumn;
	              				row[2] = thirdcolumn;
	              				row[3] = fourthcolumn;

	              				dtm.addRow(row);
	              			
	              		}

	              			r.close();
	              		}

	              		catch (Exception e2) {
	              			System.out.println("Reading doesn't work!");
	              		}

	                  }
            			scrollPane_2.setViewportView(tripdata);
            			tripdata.setModel(dtm);
            			contentPane.add(scrollPane_2);
	              } 
			}
		});
		btnReadAnotherFile.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnReadAnotherFile.setBounds(639, 506, 204, 54);
		contentPane.add(btnReadAnotherFile);
  }	
}	